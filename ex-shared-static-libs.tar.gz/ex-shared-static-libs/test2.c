#include <stdio.h>
void ptest2(void)
{
    printf("Hallo Thomas from %s\n", __FILE__);
}