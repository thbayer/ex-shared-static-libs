#!/bin/sh

# This shell script is a build helper script for compiling a C/C++ project with 
# optional cross-compilation support, and installing the resulting binaries and
# libraries into a Buildroot target folder for installation via overlay.
# 
# Command line example when using without Buildroot:
# ./build.sh -x arm-cortex_a8-linux-gnueabihf- -p /home/user/x-tools/arm-cortex_a8-linux-gnueabihf/bin/
#
# Buildroot config example
# System configuration
#   -> Root filesystem overlay directories -> $(TARGET_DIR)/custom_overlay
#   -> Custom scripts to run before commencing the build -> /home/user/ex/ex-shared-static-libs/build.sh 
#   -> Extra arguments passed to BR2_ROOTFS_PRE_BUILD_SCRIPT -> -t $(TARGET_DIR) -x $(TARGET_CROSS)


# === Defaults ===
VERBOSE=0
POSITIONAL_ARGS=()

# === Usage info ===
usage() {
    echo "Usage: $0 [options] [positional args]"
    echo
    echo "Options:"
    echo "  -v, --verbose           Enable verbose mode"
    echo "  -x, --cross-compile     Cross compiler - example: -x aarch64-unknown-linux-gnu-"
    echo "  -p, --cross-path        Path to cross compiler - example -p /home/user/x-tools/aarch64-unknown-linux-gnu/bin"
    echo "  -h, --help              Show this help"
    exit 1
}

# === Parse args ===
while [[ $# -gt 0 ]]; do
    case "$1" in
        -v|--verbose)
            VERBOSE=1
            shift
            ;;
        -x|--cross-compile)
            if [ -d $(dirname "$2") ]; then 
                export CROSS_COMPILE="$2"
                shift 2
            else
                exit 0
            fi
            ;;
        -p|--cross-path)
            export PATH="$2:$PATH"
            shift 2
            ;;
        -t|--target-dir)
            TARGET_DIR="$2"
            shift 2
            ;;
        -c)
            shift 2
            ;;
        -*)
            echo "Unknown option: $1"
            usage
            ;;
        *)
            POSITIONAL_ARGS+=("$1") # Save positional arg
            shift
            ;;
    esac
done

# Restore positional arguments
set -- "${POSITIONAL_ARGS[@]}"

# === Debug output ===
echo "VERBOSE = $VERBOSE"
echo "CROSS_COMPILE = $CROSS_COMPILE"
echo "TARGET_DIR = $TARGET_DIR"
echo "PATH = $PATH"
echo "Positional arguments: $@"

# === Main logic ===
echo "Script location: $(readlink -f "$0")"
echo "Current working directory: $(pwd)"

# Change to the directory where this script is located
cd "$(dirname "$0")" || { echo "cd failed"; exit 1; }
echo "Changed directory to: $(pwd)"


# Call make
make clean
make 

# Installation into the Buildroot target folder for installation via overlay
if [ -z "$TARGET_DIR" ]; then
    exit 0
fi

mkdir -p $TARGET_DIR/custom_overlay/usr/bin
mkdir -p $TARGET_DIR/custom_overlay/usr/lib
cp helloworld-shared helloworld-static $TARGET_DIR/custom_overlay/usr/bin
cp libtest.a libtest.so $TARGET_DIR/custom_overlay/usr/lib



