#include <stdio.h>
void ptest1(void)
{
    printf("Hallo Thomas from %s\n", __FILE__);
}